# Tetris-JavaScript

The Tetris game, created using JavaScript, and The HTML5 canvas.

Download the starter template, and follow the tutorial on youtube step by step.

Tutorial link : https://www.youtube.com/watch?v=HEsAr2Yt2do
